using System;

namespace MapleStoryMacro
{
    /// <summary>
    /// ����έp���O
    /// </summary>
    public class PlaybackStatistics
    {
        /// <summary>
        /// �`���񦸼�
        /// </summary>
        public int TotalPlayCount { get; set; } = 0;

        /// <summary>
        /// �`����ɪ��]���^
        /// </summary>
        public double TotalPlayTimeSeconds { get; set; } = 0;

        /// <summary>
        /// �̫Ἵ��ɶ�
        /// </summary>
        public DateTime? LastPlayTime { get; set; } = null;

        /// <summary>
        /// �����}�l�ɶ�
        /// </summary>
        public DateTime? CurrentSessionStart { get; set; } = null;

        /// <summary>
        /// �������񪺴`������
        /// </summary>
        public int CurrentLoopCount { get; set; } = 0;

        /// <summary>
        /// �۩w�q����Ĳ�o���� (15�ӼѦ�)
        /// </summary>
        public int[] CustomKeyTriggerCounts { get; set; } = new int[15];

        /// <summary>
        /// �}�l�s�����񶥬q
        /// </summary>
        public void StartSession()
        {
            CurrentSessionStart = DateTime.Now;
            CurrentLoopCount = 0;
            for (int i = 0; i < 15; i++)
                CustomKeyTriggerCounts[i] = 0;
        }

        /// <summary>
        /// �������񶥬q
        /// </summary>
        public void EndSession()
        {
            if (CurrentSessionStart.HasValue)
            {
                TotalPlayTimeSeconds += (DateTime.Now - CurrentSessionStart.Value).TotalSeconds;
                LastPlayTime = DateTime.Now;
            }
            TotalPlayCount++;
            CurrentSessionStart = null;
        }

        /// <summary>
        /// �W�[�`���p��
        /// </summary>
        public void IncrementLoop()
        {
            CurrentLoopCount++;
        }

        /// <summary>
        /// �O���۩w�q����Ĳ�o
        /// </summary>
        public void RecordCustomKeyTrigger(int slotIndex)
        {
            if (slotIndex >= 0 && slotIndex < 15)
                CustomKeyTriggerCounts[slotIndex]++;
        }

        /// <summary>
        /// ���o�榡�ƪ��έp��T
        /// </summary>
        public string GetFormattedStats()
        {
            string lastPlay = LastPlayTime.HasValue
                ? LastPlayTime.Value.ToString("yyyy-MM-dd HH:mm:ss")
                : "�q������";

            TimeSpan totalTime = TimeSpan.FromSeconds(TotalPlayTimeSeconds);
            string totalTimeStr = $"{(int)totalTime.TotalHours:D2}:{totalTime.Minutes:D2}:{totalTime.Seconds:D2}";

            return $"�`���񦸼�: {TotalPlayCount}\n" +
                   $"�`����ɪ�: {totalTimeStr}\n" +
                   $"�̫Ἵ��: {lastPlay}";
        }

        /// <summary>
        /// ���o�Y�ɲέp��T�]�]�t���e�|�ܪ��Y�ɸ�ơ^
        /// </summary>
        public string GetLiveFormattedStats()
        {
            double liveTotalSeconds = TotalPlayTimeSeconds;
            string sessionElapsed = "--:--:--";
            bool isActive = CurrentSessionStart.HasValue;

            if (isActive)
            {
                double currentSessionSeconds = (DateTime.Now - CurrentSessionStart.Value).TotalSeconds;
                liveTotalSeconds += currentSessionSeconds;
                TimeSpan sessionTime = TimeSpan.FromSeconds(currentSessionSeconds);
                sessionElapsed = $"{(int)sessionTime.TotalHours:D2}:{sessionTime.Minutes:D2}:{sessionTime.Seconds:D2}";
            }

            string lastPlay = LastPlayTime.HasValue
                ? LastPlayTime.Value.ToString("yyyy-MM-dd HH:mm:ss")
                : "�q������";

            TimeSpan totalTime = TimeSpan.FromSeconds(liveTotalSeconds);
            string totalTimeStr = $"{(int)totalTime.TotalHours:D2}:{totalTime.Minutes:D2}:{totalTime.Seconds:D2}";

            string status = isActive ? "?? ����" : "?? �w����";

            return $"���A: {status}\n" +
                   $"���e�|�ܮɪ�: {sessionElapsed}\n" +
                   $"���e�`��: {CurrentLoopCount}\n" +
                   $"�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w\n" +
                   $"�֭p���񦸼�: {TotalPlayCount + (isActive ? 1 : 0)}\n" +
                   $"�֭p����ɪ�: {totalTimeStr}\n" +
                   $"�̫Ἵ��: {lastPlay}";
        }

        /// <summary>
        /// ���m�Ҧ��έp
        /// </summary>
        public void Reset()
        {
            TotalPlayCount = 0;
            TotalPlayTimeSeconds = 0;
            LastPlayTime = null;
            CurrentSessionStart = null;
            CurrentLoopCount = 0;
            CustomKeyTriggerCounts = new int[15];
        }
    }
}
